//
//  WROriginalView.h
//  我的微博
//
//  Created by apple-jd28 on 15/10/29.
//  Copyright © 2015年 apple-jd28. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WRStatusFrame;
@interface WROriginalView : UIImageView

@property (nonatomic, strong) WRStatusFrame *originFrame;


@end
