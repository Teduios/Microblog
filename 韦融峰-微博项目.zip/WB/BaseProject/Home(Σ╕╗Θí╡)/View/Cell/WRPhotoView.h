//
//  WRPhotoView.h
//  我的微博
//
//  Created by apple-jd28 on 15/10/30.
//  Copyright © 2015年 apple-jd28. All rights reserved.
//

#import <UIKit/UIKit.h>

@class StatusPicUrlsModel;
@interface WRPhotoView : UIImageView

@property (nonatomic, strong) StatusPicUrlsModel *photo;

@end
