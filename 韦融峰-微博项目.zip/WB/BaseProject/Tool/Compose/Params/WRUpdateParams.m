
//
//  WRUpdateParams.m
//  BaseProject
//
//  Created by apple-jd28 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WRUpdateParams.h"

@implementation WRUpdateParams

@end
