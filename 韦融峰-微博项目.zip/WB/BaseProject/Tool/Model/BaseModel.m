//
//  BaseModel.m
//  我的微博
//
//  Created by apple-jd28 on 15/10/24.
//  Copyright © 2015年 apple-jd28. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel

@end
